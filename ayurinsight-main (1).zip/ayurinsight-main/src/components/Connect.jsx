// import React, { useState } from "react";
// import { motion } from "framer-motion";
// import { FaSearch, FaEnvelope, FaTimes, FaLeaf, FaAward, FaClock, FaUserMd } from "react-icons/fa";

// const Connect = () => {
//   // Updated mentor data with traditional Ayurvedic names
//   const initialMentors = [
//     {
//       id: 1,
//       name: "Vaidya Arjun Dev",
//       position: "Ayurvedic Healer",
//       experience: "15 years",
//       awards: "Ayurveda Ratna 2022",
//       image: "https://via.placeholder.com/100", // Placeholder image
//     },
//     {
//       id: 2,
//       name: "Vaidya Priya Nanda",
//       position: "Herbal Wisdom Keeper",
//       experience: "12 years",
//       awards: "AyurShakti Award 2021",
//       image: "https://via.placeholder.com/100", // Placeholder image
//     },
//     {
//       id: 3,
//       name: "Vaidya Sanjay Mishra",
//       position: "Panchakarma Master",
//       experience: "20 years",
//       awards: "Global Ayurveda Sage 2023",
//       image: "https://via.placeholder.com/100", // Placeholder image
//     },
//     {
//       id: 4,
//       name: "Vaidya Meera Suri",
//       position: "Ayurvedic Nutrition Sage",
//       experience: "8 years",
//       awards: "Healing Innovator 2020",
//       image: "https://via.placeholder.com/100", // Placeholder image
//     },
//   ];

//   // State for email popup, selected mentor, search query, filtered mentors, and expanded card
//   const [isPopupOpen, setIsPopupOpen] = useState(false);
//   const [selectedMentor, setSelectedMentor] = useState(null);
//   const [subject, setSubject] = useState("");
//   const [body, setBody] = useState("");
//   const [searchQuery, setSearchQuery] = useState("");
//   const [filteredMentors, setFilteredMentors] = useState(initialMentors);
//   const [expandedMentor, setExpandedMentor] = useState(null);

//   // Handle search input change and filter mentors in real-time
//   const handleSearchChange = (e) => {
//     const query = e.target.value.toLowerCase();
//     setSearchQuery(query);

//     if (query === "") {
//       setFilteredMentors(initialMentors);
//     } else {
//       const filtered = initialMentors.filter(
//         (mentor) =>
//           mentor.name.toLowerCase().includes(query) ||
//           mentor.position.toLowerCase().includes(query) ||
//           mentor.experience.toLowerCase().includes(query) ||
//           mentor.awards.toLowerCase().includes(query)
//       );
//       setFilteredMentors(filtered);
//     }
//   };

//   // Handle opening the email popup
//   const handleMailClick = (mentor) => {
//     setSelectedMentor(mentor);
//     setIsPopupOpen(true);
//   };

//   // Handle sending the email (simulated with an alert)
//   const handleSendEmail = () => {
//     alert("Email sent successfully!");
//     setIsPopupOpen(false);
//     setSubject("");
//     setBody("");
//   };

//   // Handle card click to expand/collapse
//   const handleCardClick = (mentor) => {
//     setExpandedMentor(expandedMentor?.id === mentor.id ? null : mentor);
//   };

//   // Framer Motion animation variants
//   const fadeIn = {
//     hidden: { opacity: 0 },
//     visible: { opacity: 1, transition: { duration: 0.8, ease: "easeOut" } },
//   };

//   const slideUp = {
//     hidden: { opacity: 0, y: 30 },
//     visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
//   };

//   const scaleUp = {
//     hidden: { opacity: 0, scale: 0.9 },
//     visible: { opacity: 1, scale: 1, transition: { duration: 0.5, ease: "easeOut" } },
//   };

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-[#F5F5F5] to-[#E6ECEA] font-poppins text-[#4A4A4A] pt-24 px-6">
//       {/* Title and Subtitle */}
//       <motion.header
//         className="text-center mb-16"
//         initial="hidden"
//         animate="visible"
//         variants={fadeIn}
//       >
//         <h1 className="text-5xl md:text-6xl font-playfair text-[#2E8B57] mb-6 drop-shadow-md">
//           Connect with Ayurvedic Sages
//         </h1>
//         <p className="text-lg md:text-xl max-w-3xl mx-auto leading-relaxed">
//           Seek Wisdom from Esteemed Ayurvedic Mentors
//         </p>
//       </motion.header>

//       {/* Search Bar */}
//       <motion.div
//         className="flex justify-center mb-12"
//         initial="hidden"
//         animate="visible"
//         variants={slideUp}
//       >
//         <div className="relative w-full max-w-md">
//           <FaSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-[#2E8B57] text-xl" />
//           <input
//             type="text"
//             placeholder="Search Ayurvedic Sages..."
//             value={searchQuery}
//             onChange={handleSearchChange}
//             className="w-full p-4 pl-12 text-[#4A4A4A] rounded-full border-2 border-[#2E8B57] focus:outline-none focus:border-[#FFD700] transition-all text-lg bg-white shadow-lg"
//           />
//         </div>
//       </motion.div>

//       {/* Mentor Cards */}
//       <div className="max-w-6xl mx-auto">
//         {filteredMentors.length > 0 ? (
//           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
//             {filteredMentors.map((mentor) => (
//               <motion.div
//                 key={mentor.id}
//                 className="bg-white rounded-2xl shadow-xl p-6 cursor-pointer border border-[#2E8B57]/10"
//                 initial="hidden"
//                 animate="visible"
//                 variants={slideUp}
//                 whileHover={{ scale: 1.05 }}
//                 whileTap={{ scale: 0.98 }}
//                 onClick={() => handleCardClick(mentor)}
//               >
//                 <div className="flex flex-col items-center">
//                   <img
//                     src={mentor.image}
//                     alt={mentor.name}
//                     className="w-24 h-24 rounded-full mb-4 object-cover border-2 border-[#2E8B57] shadow-md"
//                   />
//                   <h2 className="text-xl font-playfair text-[#2E8B57] mb-2">{mentor.name}</h2>
//                   <p className="text-gray-600 text-center">{mentor.position}</p>
//                 </div>
//               </motion.div>
//             ))}
//           </div>
//         ) : (
//           <motion.div
//             className="text-center text-gray-600 text-lg"
//             initial="hidden"
//             animate="visible"
//             variants={fadeIn}
//           >
//             No Ayurvedic Sages found matching your search.
//           </motion.div>
//         )}
//       </div>

//       {/* Expanded Mentor Card */}
//       {expandedMentor && (
//         <motion.div
//           className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
//           initial={{ opacity: 0 }}
//           animate={{ opacity: 1 }}
//           exit={{ opacity: 0 }}
//           transition={{ duration: 0.3 }}
//         >
//           <motion.div
//             className="bg-white rounded-2xl shadow-2xl p-8 max-w-3xl w-full border border-[#2E8B57]/20 relative"
//             initial={{ scale: 0.9, opacity: 0 }}
//             animate={{ scale: 1, opacity: 1 }}
//             exit={{ scale: 0.9, opacity: 0 }}
//             transition={{ duration: 0.3 }}
//           >
//             <button
//               onClick={() => setExpandedMentor(null)}
//               className="absolute top-4 right-4 text-[#2E8B57] hover:text-[#FFD700] transition-colors"
//             >
//               <FaTimes className="text-2xl" />
//             </button>
//             <div className="flex flex-col md:flex-row gap-6">
//               {/* Left Side: Photo, Name, Mail Button */}
//               <div className="flex flex-col items-center md:w-1/3">
//                 <img
//                   src={expandedMentor.image}
//                   alt={expandedMentor.name}
//                   className="w-32 h-32 rounded-full mb-4 object-cover border-2 border-[#2E8B57] shadow-lg"
//                 />
//                 <h2 className="text-2xl font-playfair text-[#2E8B57] mb-4 text-center">{expandedMentor.name}</h2>
//                 <motion.button
//                   className="bg-[#FFD700] text-[#2E8B57] py-3 px-6 rounded-full text-lg font-medium hover:bg-[#2E8B57] hover:text-white transition-all duration-300 shadow-md hover:shadow-lg flex items-center gap-2"
//                   whileHover={{ scale: 1.1 }}
//                   whileTap={{ scale: 0.98 }}
//                   onClick={() => handleMailClick(expandedMentor)}
//                 >
//                   <FaEnvelope className="text-xl" />
//                   Mail Sage
//                 </motion.button>
//               </div>
//               {/* Right Side: Details */}
//               <div className="md:w-2/3 space-y-4">
//                 <div className="flex items-center gap-2">
//                   <FaUserMd className="text-[#2E8B57] text-xl" />
//                   <p className="text-lg text-[#4A4A4A]">
//                     <strong>Position:</strong> {expandedMentor.position}
//                   </p>
//                 </div>
//                 <div className="flex items-center gap-2">
//                   <FaClock className="text-[#2E8B57] text-xl" />
//                   <p className="text-lg text-[#4A4A4A]">
//                     <strong>Experience:</strong> {expandedMentor.experience}
//                   </p>
//                 </div>
//                 <div className="flex items-center gap-2">
//                   <FaAward className="text-[#2E8B57] text-xl" />
//                   <p className="text-lg text-[#4A4A4A]">
//                     <strong>Awards:</strong> {expandedMentor.awards}
//                   </p>
//                 </div>
//               </div>
//             </div>
//           </motion.div>
//         </motion.div>
//       )}

//       {/* Email Popup */}
//       {isPopupOpen && (
//         <motion.div
//           className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
//           initial={{ opacity: 0 }}
//           animate={{ opacity: 1 }}
//           exit={{ opacity: 0 }}
//           transition={{ duration: 0.3 }}
//         >
//           <motion.div
//             className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full border border-[#2E8B57]/20"
//             initial={{ scale: 0.9, opacity: 0 }}
//             animate={{ scale: 1, opacity: 1 }}
//             exit={{ scale: 0.9, opacity: 0 }}
//             transition={{ duration: 0.3 }}
//           >
//             <div className="flex justify-between items-center mb-6">
//               <h2 className="text-2xl font-playfair text-[#2E8B57] flex items-center gap-2">
//                 <FaEnvelope className="text-[#2E8B57]" /> Compose Message to {selectedMentor?.name}
//               </h2>
//               <button
//                 onClick={() => setIsPopupOpen(false)}
//                 className="text-[#2E8B57] hover:text-[#FFD700] transition-colors"
//               >
//                 <FaTimes className="text-2xl" />
//               </button>
//             </div>
//             <div className="mb-6">
//               <label className="block text-[#4A4A4A] mb-2 font-medium">Subject</label>
//               <input
//                 type="text"
//                 value={subject}
//                 onChange={(e) => setSubject(e.target.value)}
//                 className="w-full p-3 border-2 border-[#2E8B57] rounded-lg focus:outline-none focus:border-[#FFD700] transition-all bg-white shadow-inner"
//                 placeholder="Enter subject..."
//               />
//             </div>
//             <div className="mb-6">
//               <label className="block text-[#4A4A4A] mb-2 font-medium">Message</label>
//               <textarea
//                 value={body}
//                 onChange={(e) => setBody(e.target.value)}
//                 className="w-full p-3 border-2 border-[#2E8B57] rounded-lg focus:outline-none focus:border-[#FFD700] transition-all bg-white shadow-inner"
//                 rows="5"
//                 placeholder="Enter your message..."
//               />
//             </div>
//             <div className="flex justify-end space-x-3">
//               <motion.button
//                 onClick={() => setIsPopupOpen(false)}
//                 className="bg-gray-200 text-[#4A4A4A] py-2 px-6 rounded-full font-medium hover:bg-gray-300 transition-all shadow-md"
//                 whileHover={{ scale: 1.1 }}
//                 whileTap={{ scale: 0.98 }}
//               >
//                 Cancel
//               </motion.button>
//               <motion.button
//                 onClick={handleSendEmail}
//                 className="bg-[#2E8B57] text-white py-2 px-6 rounded-full font-medium hover:bg-[#FFD700] hover:text-[#2E8B57] transition-all shadow-md"
//                 whileHover={{ scale: 1.1 }}
//                 whileTap={{ scale: 0.98 }}
//               >
//                 Send
//               </motion.button>
//             </div>
//           </motion.div>
//         </motion.div>
//       )}
//     </div>
//   );
// };

// export default Connect;




























// import React, { useState, useEffect } from "react";
// import { motion } from "framer-motion";
// import { FaSearch, FaEnvelope, FaTimes, FaLeaf, FaAward, FaClock, FaUserMd } from "react-icons/fa";

// const Connect = () => {
//   const [isPopupOpen, setIsPopupOpen] = useState(false);
//   const [selectedMentor, setSelectedMentor] = useState(null);
//   const [subject, setSubject] = useState("");
//   const [body, setBody] = useState("");
//   const [searchQuery, setSearchQuery] = useState("");
//   const [filteredMentors, setFilteredMentors] = useState([]);
//   const [expandedMentor, setExpandedMentor] = useState(null);
//   const [mentors, setMentors] = useState([]);

//   // Fetch doctors.json on component mount
//   useEffect(() => {
//     fetch("/doctors.json")
//       .then((response) => response.json())
//       .then((jsonData) => {
//         setMentors(jsonData);
//         setFilteredMentors(jsonData); // Initialize filtered mentors
//       })
//       .catch((error) => console.error("Error fetching doctors:", error));
//   }, []);

//   // Handle search input change and filter mentors in real-time
//   const handleSearchChange = (e) => {
//     const query = e.target.value.toLowerCase();
//     setSearchQuery(query);

//     if (query === "") {
//       setFilteredMentors(mentors);
//     } else {
//       const filtered = mentors.filter(
//         (mentor) =>
//           mentor.name.toLowerCase().includes(query) ||
//           mentor.position.toLowerCase().includes(query) ||
//           mentor.experience.toLowerCase().includes(query) ||
//           mentor.awardsAndRecognitions.toLowerCase().includes(query) ||
//           mentor.fieldOfStudy.toLowerCase().includes(query)
//       );
//       setFilteredMentors(filtered);
//     }
//   };

//   // Handle opening the email popup
//   const handleMailClick = (mentor) => {
//     setSelectedMentor(mentor);
//     setIsPopupOpen(true);
//   };

//   // Handle sending the email (simulated with an alert)
//   const handleSendEmail = () => {
//     alert("Email sent successfully!");
//     setIsPopupOpen(false);
//     setSubject("");
//     setBody("");
//   };

//   const handleCardClick = (mentor) => {
//     setExpandedMentor(expandedMentor && expandedMentor.id === mentor.id ? null : mentor);
//   };
//   // Framer Motion animation variants
//   const fadeIn = {
//     hidden: { opacity: 0 },
//     visible: { opacity: 1, transition: { duration: 0.8, ease: "easeOut" } },
//   };

//   const slideUp = {
//     hidden: { opacity: 0, y: 30 },
//     visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
//   };

//   const scaleUp = {
//     hidden: { opacity: 0, scale: 0.9 },
//     visible: { opacity: 1, scale: 1, transition: { duration: 0.5, ease: "easeOut" } },
//   };

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-[#F5F5F5] to-[#E6ECEA] font-poppins text-[#4A4A4A] pt-24 pb-24 px-6 flex flex-col">
//       {/* Title and Subtitle */}
//       <motion.header
//         className="text-center mb-16"
//         initial="hidden"
//         animate="visible"
//         variants={fadeIn}
//       >
//         <h1 className="text-5xl md:text-6xl font-playfair text-[#2E8B57] mb-6 drop-shadow-md">
//           Connect with Ayurvedic Sages
//         </h1>
//         <p className="text-lg md:text-xl max-w-3xl mx-auto leading-relaxed">
//           Seek Wisdom from Esteemed Ayurvedic Mentors
//         </p>
//       </motion.header>

//       {/* Search Bar */}
//       <motion.div
//         className="flex justify-center mb-12"
//         initial="hidden"
//         animate="visible"
//         variants={slideUp}
//       >
//         <div className="relative w-full max-w-md">
//           <FaSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-[#2E8B57] text-xl" />
//           <input
//             type="text"
//             placeholder="Search Ayurvedic Sages..."
//             value={searchQuery}
//             onChange={handleSearchChange}
//             className="w-full p-4 pl-12 text-[#4A4A4A] rounded-full border-2 border-[#2E8B57] focus:outline-none focus:border-[#FFD700] transition-all text-lg bg-white shadow-lg"
//           />
//         </div>
//       </motion.div>

//       {/* Mentor Cards */}
//       <div className="max-w-6xl mx-auto flex-1">
//         {filteredMentors.length > 0 ? (
//           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
//             {filteredMentors.map((mentor) => (
//               <motion.div
//                 key={mentor.id}
//                 className="bg-white rounded-2xl shadow-xl p-6 cursor-pointer border border-[#2E8B57]/10"
//                 initial="hidden"
//                 animate="visible"
//                 variants={slideUp}
//                 whileHover={{ scale: 1.05 }}
//                 whileTap={{ scale: 0.98 }}
//                 onClick={() => handleCardClick(mentor)}
//               >
//                 <div className="flex flex-col items-center">
//                   <img
//                     src={mentor.imageUrl}
//                     alt={mentor.name}
//                     className="w-24 h-24 rounded-full mb-4 object-cover border-2 border-[#2E8B57] shadow-md"
//                   />
//                   <h2 className="text-xl font-playfair text-[#2E8B57] mb-2">{mentor.name}</h2>
//                   <p className="text-gray-600 text-center">{mentor.position}</p>
//                 </div>
//               </motion.div>
//             ))}
//           </div>
//         ) : (
//           <motion.div
//             className="text-center text-gray-600 text-lg"
//             initial="hidden"
//             animate="visible"
//             variants={fadeIn}
//           >
//             No Ayurvedic Sages found matching your search.
//           </motion.div>
//         )}
//       </div>

//       {/* Expanded Mentor Card */}
//       {expandedMentor && (
//         <motion.div
//           className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
//           initial={{ opacity: 0 }}
//           animate={{ opacity: 1 }}
//           exit={{ opacity: 0 }}
//           transition={{ duration: 0.3 }}
//         >
//           <motion.div
//             className="bg-white rounded-2xl shadow-2xl p-8 max-w-3xl w-full border border-[#2E8B57]/20 relative"
//             initial={{ scale: 0.9, opacity: 0 }}
//             animate={{ scale: 1, opacity: 1 }}
//             exit={{ scale: 0.9, opacity: 0 }}
//             transition={{ duration: 0.3 }}
//           >
//             <button
//               onClick={() => setExpandedMentor(null)}
//               className="absolute top-4 right-4 text-[#2E8B57] hover:text-[#FFD700] transition-colors cursor-pointer"
//             >
//               <FaTimes className="text-2xl" />
//             </button>
//             <div className="flex flex-col md:flex-row gap-6">
//               {/* Left Side: Photo, Name, Mail Button */}
//               <div className="flex flex-col items-center md:w-1/3">
//                 <img
//                   src={expandedMentor.imageUrl}
//                   alt={expandedMentor.name}
//                   className="w-32 h-32 rounded-full mb-4 object-cover border-2 border-[#2E8B57] shadow-lg"
//                 />
//                 <h2 className="text-2xl font-playfair text-[#2E8B57] mb-4 text-center">{expandedMentor.name}</h2>
//                 <motion.button
//                   className="bg-[#FFD700] text-[#2E8B57] py-3 px-6 rounded-full text-lg font-medium hover:bg-[#2E8B57] hover:text-white transition-all duration-300 shadow-md hover:shadow-lg flex items-center gap-2 cursor-pointer"
//                   whileHover={{ scale: 1.1 }}
//                   whileTap={{ scale: 0.98 }}
//                   onClick={() => handleMailClick(expandedMentor)}
//                 >
//                   <FaEnvelope className="text-xl " />
//                   Mail Sage
//                 </motion.button>
//               </div>
//               {/* Right Side: Details */}
//               <div className="md:w-2/3 space-y-4">
//                 <div className="flex items-center gap-2">
//                   <FaUserMd className="text-[#2E8B57] text-xl" />
//                   <p className="text-lg text-[#4A4A4A]">
//                     <strong>Position:</strong> {expandedMentor.position}
//                   </p>
//                 </div>
//                 <div className="flex items-center gap-2">
//                   <FaClock className="text-[#2E8B57] text-xl" />
//                   <p className="text-lg text-[#4A4A4A]">
//                     <strong>Experience:</strong> {expandedMentor.experience}
//                   </p>
//                 </div>
//                 <div className="flex items-center gap-2">
//                   <FaAward className="text-[#2E8B57] text-xl" />
//                   <p className="text-lg text-[#4A4A4A]">
//                     <strong>Awards:</strong> {expandedMentor.awardsAndRecognitions}
//                   </p>
//                 </div>
//                 <div className="flex items-center gap-2">
//                   <FaLeaf className="text-[#2E8B57] text-xl" />
//                   <p className="text-lg text-[#4A4A4A]">
//                     <strong>Field of Study:</strong> {expandedMentor.fieldOfStudy}
//                   </p>
//                 </div>
//               </div>
//             </div>
//           </motion.div>
//         </motion.div>
//       )}

//       {/* Email Popup */}
//       {isPopupOpen && (
//         <motion.div
//           className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
//           initial={{ opacity: 0 }}
//           animate={{ opacity: 1 }}
//           exit={{ opacity: 0 }}
//           transition={{ duration: 0.3 }}
//         >
//           <motion.div
//             className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full border border-[#2E8B57]/20"
//             initial={{ scale: 0.9, opacity: 0 }}
//             animate={{ scale: 1, opacity: 1 }}
//             exit={{ scale: 0.9, opacity: 0 }}
//             transition={{ duration: 0.3 }}
//           >
//             <div className="flex justify-between items-center mb-6">
//               <h2 className="text-2xl font-playfair text-[#2E8B57] flex items-center gap-2">
//                 <FaEnvelope className="text-[#2E8B57]" /> Send Message to {selectedMentor?.name}
//               </h2>
//               <button
//                 onClick={() => setIsPopupOpen(false)}
//                 className="text-[#2E8B57] hover:text-[#FFD700] transition-colors"
//               >
//                 <FaTimes className="text-2xl" />
//               </button>
//             </div>
//             <div className="mb-6">
//               <label className="block text-[#4A4A4A] mb-2 font-medium">Subject</label>
//               <input
//                 type="text"
//                 value={subject}
//                 onChange={(e) => setSubject(e.target.value)}
//                 className="w-full p-3 border-2 border-[#2E8B57] rounded-lg focus:outline-none focus:border-[#FFD700] transition-all bg-white shadow-inner"
//                 placeholder="Enter subject..."
//               />
//             </div>
//             <div className="mb-6">
//               <label className="block text-[#4A4A4A] mb-2 font-medium">Message</label>
//               <textarea
//                 value={body}
//                 onChange={(e) => setBody(e.target.value)}
//                 className="w-full p-3 border-2 border-[#2E8B57] rounded-lg focus:outline-none focus:border-[#FFD700] transition-all bg-white shadow-inner"
//                 rows="5"
//                 placeholder="Enter your message..."
//               />
//             </div>
//             <div className="flex justify-end space-x-3">
//               <motion.button
//                 onClick={() => setIsPopupOpen(false)}
//                 className="bg-gray-200 text-[#4A4A4A] py-2 px-6 rounded-full font-medium hover:bg-gray-300 transition-all shadow-md"
//                 whileHover={{ scale: 1.1 }}
//                 whileTap={{ scale: 0.98 }}
//               >
//                 Cancel
//               </motion.button>
//               <motion.button
//                 onClick={handleSendEmail}
//                 className="bg-[#2E8B57] text-white py-2 px-6 rounded-full font-medium hover:bg-[#FFD700] hover:text-[#2E8B57] transition-all shadow-md"
//                 whileHover={{ scale: 1.1 }}
//                 whileTap={{ scale: 0.98 }}
//               >
//                 Send
//               </motion.button>
//             </div>
//           </motion.div>
//         </motion.div>
//       )}
//     </div>
//   );
// };

// export default Connect;






















































import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { FaSearch, FaEnvelope, FaTimes, FaLeaf, FaAward, FaClock, FaUserMd } from "react-icons/fa";

const Connect = () => {
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [selectedMentor, setSelectedMentor] = useState(null);
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredMentors, setFilteredMentors] = useState([]);
  const [expandedMentor, setExpandedMentor] = useState(null);
  const [mentors, setMentors] = useState([]);

  //logic to search profiles
  useEffect(() => {
    fetch("/doctors.json")
      .then((response) => response.json())
      .then((jsonData) => {
        setMentors(jsonData);
        setFilteredMentors(jsonData);
      })
      .catch((error) => console.error("Error fetching doctors:", error));
  }, []);

  const handleSearchChange = (e) => {
    const query = e.target.value.toLowerCase();
    setSearchQuery(query);

    if (query === "") {
      setFilteredMentors(mentors);
    } else {
      const filtered = mentors.filter(
        (mentor) =>
          mentor.name.toLowerCase().includes(query) ||
          mentor.position.toLowerCase().includes(query) ||
          mentor.experience.toLowerCase().includes(query) ||
          mentor.awardsAndRecognitions.toLowerCase().includes(query) ||
          mentor.fieldOfStudy.toLowerCase().includes(query)
      );
      setFilteredMentors(filtered);
    }
  };

  const handleMailClick = (mentor) => {
    setSelectedMentor(mentor);
    setIsPopupOpen(true);
  };

  const handleSendEmail = () => {
    if (selectedMentor && selectedMentor.email) {
      // Encode subject and body for URL
      const encodedSubject = encodeURIComponent(subject);
      const encodedBody = encodeURIComponent(body);
      
      // Construct Gmail URL
      const gmailUrl = `https://mail.google.com/mail/u/0/?fs=1&to=${selectedMentor.email}&su=${encodedSubject}&body=${encodedBody}&tf=cm`;
      
      // Open in new tab
      window.open(gmailUrl, '_blank');
      
      // Close popup and reset fields
      setIsPopupOpen(false);
      setSubject("");
      setBody("");
    } else {
      alert("Error: No email address available for this mentor.");
    }
  };

  const handleCardClick = (mentor) => {
    setExpandedMentor(expandedMentor && expandedMentor.id === mentor.id ? null : mentor);
  };

  const fadeIn = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.8, ease: "easeOut" } },
  };

  const slideUp = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5F5F5] to-[#E6ECEA] font-poppins text-[#4A4A4A] pt-24 pb-24 px-6 flex flex-col">
      <motion.header
        className="text-center mb-16"
        initial="hidden"
        animate="visible"
        variants={fadeIn}
      >
        <h1 className="text-5xl md:text-6xl font-playfair text-[#2E8B57] mb-6 drop-shadow-md">
          Connect with Ayurvedic Sages
        </h1>
        <p className="text-lg md:text-xl max-w-3xl mx-auto leading-relaxed">
          Seek Wisdom from Esteemed Ayurvedic Mentors
        </p>
      </motion.header>

      <motion.div
        className="flex justify-center mb-12"
        initial="hidden"
        animate="visible"
        variants={slideUp}
      >
        <div className="relative w-full max-w-md">
          <FaSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-[#2E8B57] text-xl" />
          <input
            type="text"
            placeholder="Search Ayurvedic Sages..."
            value={searchQuery}
            onChange={handleSearchChange}
            className="w-full p-4 pl-12 text-[#4A4A4A] rounded-full border-2 border-[#2E8B57] focus:outline-none focus:border-[#FFD700] transition-all text-lg bg-white shadow-lg"
          />
        </div>
      </motion.div>

      <div className="max-w-6xl mx-auto flex-1">
        {filteredMentors.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredMentors.map((mentor) => (
              <motion.div
                key={mentor.id}
                className="bg-white rounded-2xl shadow-xl p-6 cursor-pointer border border-[#2E8B57]/10"
                initial="hidden"
                animate="visible"
                variants={slideUp}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleCardClick(mentor)}
              >
                <div className="flex flex-col items-center">
                  <img
                    src={mentor.imageUrl}
                    alt={mentor.name}
                    className="w-24 h-24 rounded-full mb-4 object-cover border-2 border-[#2E8B57] shadow-md"
                  />
                  <h2 className="text-xl font-playfair text-[#2E8B57] mb-2">{mentor.name}</h2>
                  <p className="text-gray-600 text-center">{mentor.position}</p>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <motion.div
            className="text-center text-gray-600 text-lg"
            initial="hidden"
            animate="visible"
            variants={fadeIn}
          >
            No Ayurvedic Sages found matching your search.
          </motion.div>
        )}
      </div>

      {expandedMentor && (
        <motion.div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          <motion.div
            className="bg-white rounded-2xl shadow-2xl p-8 max-w-3xl w-full border border-[#2E8B57]/20 relative"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <button
              onClick={() => setExpandedMentor(null)}
              className="absolute top-4 right-4 text-[#2E8B57] hover:text-[#FFD700] transition-colors cursor-pointer"
            >
              <FaTimes className="text-2xl" />
            </button>
            <div className="flex flex-col md:flex-row gap-6">
              <div className="flex flex-col items-center md:w-1/3">
                <img
                  src={expandedMentor.imageUrl}
                  alt={expandedMentor.name}
                  className="w-32 h-32 rounded-full mb-4 object-cover border-2 border-[#2E8B57] shadow-lg"
                />
                <h2 className="text-2xl font-playfair text-[#2E8B57] mb-4 text-center">{expandedMentor.name}</h2>
                <motion.button
                  className="bg-[#FFD700] text-[#2E8B57] py-3 px-6 rounded-full text-lg font-medium hover:bg-[#2E8B57] hover:text-white transition-all duration-300 shadow-md hover:shadow-lg flex items-center gap-2 cursor-pointer"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleMailClick(expandedMentor)}
                >
                  <FaEnvelope className="text-xl" />
                  Mail Sage
                </motion.button>
              </div>
              <div className="md:w-2/3 space-y-4">
                <div className="flex items-center gap-2">
                  <FaUserMd className="text-[#2E8B57] text-xl" />
                  <p className="text-lg text-[#4A4A4A]">
                    <strong>Position:</strong> {expandedMentor.position}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <FaClock className="text-[#2E8B57] text-xl" />
                  <p className="text-lg text-[#4A4A4A]">
                    <strong>Experience:</strong> {expandedMentor.experience}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <FaAward className="text-[#2E8B57] text-xl" />
                  <p className="text-lg text-[#4A4A4A]">
                    <strong>Awards:</strong> {expandedMentor.awardsAndRecognitions}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <FaLeaf className="text-[#2E8B57] text-xl" />
                  <p className="text-lg text-[#4A4A4A]">
                    <strong>Field of Study:</strong> {expandedMentor.fieldOfStudy}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}

      {isPopupOpen && (
        <motion.div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          <motion.div
            className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full border border-[#2E8B57]/20"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-playfair text-[#2E8B57] flex items-center gap-2">
                <FaEnvelope className="text-[#2E8B57]" /> Send Message to {selectedMentor?.name}
              </h2>
              <button
                onClick={() => setIsPopupOpen(false)}
                className="text-[#2E8B57] hover:text-[#FFD700] transition-colors"
              >
                <FaTimes className="text-2xl" />
              </button>
            </div>
            <div className="mb-6">
              <label className="block text-[#4A4A4A] mb-2 font-medium">Subject</label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full p-3 border-2 border-[#2E8B57] rounded-lg focus:outline-none focus:border-[#FFD700] transition-all bg-white shadow-inner"
                placeholder="Enter subject..."
              />
            </div>
            <div className="mb-6">
              <label className="block text-[#4A4A4A] mb-2 font-medium">Message</label>
              <textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                className="w-full p-3 border-2 border-[#2E8B57] rounded-lg focus:outline-none focus:border-[#FFD700] transition-all bg-white shadow-inner"
                rows="5"
                placeholder="Enter your message..."
              />
            </div>
            <div className="flex justify-end space-x-3">
              <motion.button
                onClick={() => setIsPopupOpen(false)}
                className="bg-gray-200 text-[#4A4A4A] py-2 px-6 rounded-full font-medium hover:bg-gray-300 transition-all shadow-md"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.98 }}
              >
                Cancel
              </motion.button>
              <motion.button
                onClick={handleSendEmail}
                className="bg-[#2E8B57] text-white py-2 px-6 rounded-full font-medium hover:bg-[#FFD700] hover:text-[#2E8B57] transition-all shadow-md"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.98 }}
              >
                Send
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
};

export default Connect;